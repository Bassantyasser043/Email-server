import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import {HttpClient } from '@angular/common/http'
@Component({
  selector: 'app-addcontact',
  templateUrl: './addcontact.component.html',
  styleUrls: ['./addcontact.component.css']
})
export class AddcontactComponent implements OnInit {

  constructor(private router: Router, private route: ActivatedRoute,private http: HttpClient) {}

  ngOnInit(): void {
  }
primary_email:any
flag:any="true";
contact_name:any;
contact_list:any;

addcontact(){
    this.contact_list =new Map()
    this.primary_email=(<HTMLInputElement>document.getElementById("primaryEmail")).value
    this.contact_name=(<HTMLInputElement>document.getElementById("name")).value
    
    console.log(this.contact_list);
    //this.SignIn();
   
    if(this.primary_email==""){
      alert("Please enter primary Email");
    }
    else if(this.contact_name=="") alert("Please Contact Name");
    else if(this.contact_name==""&&this.primary_email=="") alert("Unsucessful");
    else{
    this.contact_list['primaryEmail']=this.primary_email
    this.contact_list['name']=this.contact_name
    }
  
}
///////
Finished(){
  this.addcontact();
  if(this.flag==="true"){
    alert("Sucessful operation");
    this.router.navigateByUrl("/home");
  }
}
back(){
  this.router.navigate(["/home"]);
}

}
